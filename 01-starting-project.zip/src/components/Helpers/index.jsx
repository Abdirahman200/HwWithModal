import React from 'react';

const index = () => {
    return props.children
};

export default index;